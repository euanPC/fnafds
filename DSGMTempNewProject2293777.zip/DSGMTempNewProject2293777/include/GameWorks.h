#include "dsgm_gfx.h"
#include "custom_gfx.h"
#include "Defines.h"
#include "ActionWorks.h"

#include "Sound_1.h"
#include "Sound_2.h"


int Variable_1 = 0;
int e = 0;
int ee = 0;
int fnaf = 0;
int Variable_2 = 0;
int fnaf2 = 0;


enum ObjectEnums { Object_1 = 1, Object_2 = 2, Object_3 = 3, Object_4 = 4, Object_5 = 5, Object_6 = 6, Object_7 = 7, Object_8 = 8, Object_9 = 9, Object_10 = 10, Object_11 = 11, Object_12 = 12, Object_13 = 13, Object_14 = 14,  };
void Set_Sprite(u8 InstanceID, char *SpriteName, bool DeleteOld);
void Create_Object(u8 ObjectEnum, u8 InstanceID, bool Screen, s16 X, s16 Y);
u8 Sprite_Get_ID(char *SpriteName);
u8 Room_Get_Index(char *RoomName);
void Goto_Room_Backend(u8 RoomIndex);
u8 Count_Instances(u8 ObjectEnum);
void Goto_Next_Room(void);

void Object_7Create_Event(u8 DAppliesTo) {
  AS_SoundQuickPlay(Sound_1);
}
void Object_8Create_Event(u8 DAppliesTo) {
  AS_SoundQuickPlay(Sound_2);
}
void Object_6TouchNewPress_Event(u8 DAppliesTo) {
  PA_LoadBackground(0, 2, &Background_4);
  ee = 3;
}
void Object_11TouchNewPress_Event(u8 DAppliesTo) {
  Goto_Next_Room();
}
void Object_14TouchNewPress_Event(u8 DAppliesTo) {
  CurrentRoom = Room_Get_Index("Room_4");
  RoomFrames = 0;
  RoomSeconds = 0;
  Room_4();
}
void Object_5TouchNewPress_Event(u8 DAppliesTo) {
  PA_LoadBackground(0, 2, &Background_3);
  ee = 1;
}
void Object_4TouchNewPress_Event(u8 DAppliesTo) {
  PA_LoadBackground(0, 2, &Background_2);
  ee = 2;
}
void Object_1ButtonPressL_Event(u8 DAppliesTo) {
  if (Variable_1 == 1) {
    Variable_1 = 0;
    u16 AppliesTo3 = 0;
    for (AppliesTo3 = 0; AppliesTo3 < 256; AppliesTo3++) {
      if (Instances[AppliesTo3].InUse && Instances[AppliesTo3].EName == Object_2) {
        Delete_Instance(AppliesTo3);
      }
    }
  }
  else {
    Create_Object(Object_2, 1, 1, 198, 66);
    Variable_1 = 1;
  }
  if (fnaf2 == -1) {
    fnaf2 = 0;
  }
}
void Object_1ButtonPressR_Event(u8 DAppliesTo) {
  if (e == 1) {
    e = 0;
    u16 AppliesTo3 = 0;
    for (AppliesTo3 = 0; AppliesTo3 < 256; AppliesTo3++) {
      if (Instances[AppliesTo3].InUse && Instances[AppliesTo3].EName == Object_3) {
        Delete_Instance(AppliesTo3);
      }
    }
  }
  else {
    e = 1;
    Create_Object(Object_3, 1, 1, 12, 67);
    u16 AppliesTo9 = 0;
    for (AppliesTo9 = 0; AppliesTo9 < 256; AppliesTo9++) {
      if (Instances[AppliesTo9].InUse && Instances[AppliesTo9].EName == Object_9) {
        Set_XY(AppliesTo9, 10, 200);
      }
    }
  }
}
void Object_1Step_Event(u8 DAppliesTo) {
  Variable_2 = Variable_2 + 1;
  if (Is_Divisible(Variable_2, 100)) {
    fnaf = fnaf+ Random(-1,1);
    fnaf2 = fnaf2+ Random(-1,1);
  }
  if (fnaf >= 2) {
    if (e == 1) {
      fnaf = 2;
      u16 AppliesTo11 = 0;
      for (AppliesTo11 = 0; AppliesTo11 < 256; AppliesTo11++) {
        if (Instances[AppliesTo11].InUse && Instances[AppliesTo11].EName == Object_9) {
          Set_XY(AppliesTo11, 1, 200);
        }
      }
    }
    else {
      u16 AppliesTo15 = 0;
      for (AppliesTo15 = 0; AppliesTo15 < 256; AppliesTo15++) {
        if (Instances[AppliesTo15].InUse && Instances[AppliesTo15].EName == Object_9) {
          Set_XY(AppliesTo15, 10, 70);
        }
      }
      if (fnaf >= 3) {
        CurrentRoom = Room_Get_Index("Room_2");
        RoomFrames = 0;
        RoomSeconds = 0;
        Room_2();
      }
    }
  }
  else {
    u16 AppliesTo24 = 0;
    for (AppliesTo24 = 0; AppliesTo24 < 256; AppliesTo24++) {
      if (Instances[AppliesTo24].InUse && Instances[AppliesTo24].EName == Object_9) {
        Set_XY(AppliesTo24, 1, 200);
      }
    }
  }
  if (fnaf == -1) {
    fnaf = 1;
  }
  if (fnaf == 0) {
    if (ee == 3) {
      u16 AppliesTo34 = 0;
      for (AppliesTo34 = 0; AppliesTo34 < 256; AppliesTo34++) {
        if (Instances[AppliesTo34].InUse && Instances[AppliesTo34].EName == Object_10) {
          Set_XY(AppliesTo34, 60, 60);
        }
      }
    }
    else {
      u16 AppliesTo38 = 0;
      for (AppliesTo38 = 0; AppliesTo38 < 256; AppliesTo38++) {
        if (Instances[AppliesTo38].InUse && Instances[AppliesTo38].EName == Object_10) {
          Set_XY(AppliesTo38, 0, 200);
        }
      }
    }
  }
  if (fnaf == 1) {
    if (ee == 1) {
      u16 AppliesTo45 = 0;
      for (AppliesTo45 = 0; AppliesTo45 < 256; AppliesTo45++) {
        if (Instances[AppliesTo45].InUse && Instances[AppliesTo45].EName == Object_10) {
          Set_XY(AppliesTo45, 20, 20);
        }
      }
    }
    else {
      u16 AppliesTo49 = 0;
      for (AppliesTo49 = 0; AppliesTo49 < 256; AppliesTo49++) {
        if (Instances[AppliesTo49].InUse && Instances[AppliesTo49].EName == Object_10) {
          Set_XY(AppliesTo49, 0, 200);
        }
      }
    }
  }
  if (fnaf == 2) {
    u16 AppliesTo54 = 0;
    for (AppliesTo54 = 0; AppliesTo54 < 256; AppliesTo54++) {
      if (Instances[AppliesTo54].InUse && Instances[AppliesTo54].EName == Object_10) {
        Set_XY(AppliesTo54, 0, 200);
      }
    }
  }
  if (fnaf2 >= 2) {
    if (Variable_1 == 1) {
      fnaf2 = 2;
      u16 AppliesTo61 = 0;
      for (AppliesTo61 = 0; AppliesTo61 < 256; AppliesTo61++) {
        if (Instances[AppliesTo61].InUse && Instances[AppliesTo61].EName == Object_12) {
          Set_XY(AppliesTo61, 1, 200);
        }
      }
    }
    else {
      u16 AppliesTo65 = 0;
      for (AppliesTo65 = 0; AppliesTo65 < 256; AppliesTo65++) {
        if (Instances[AppliesTo65].InUse && Instances[AppliesTo65].EName == Object_12) {
          Set_XY(AppliesTo65, 195, 70);
        }
      }
      if (fnaf2 >= 3) {
        CurrentRoom = Room_Get_Index("Room_3");
        RoomFrames = 0;
        RoomSeconds = 0;
        Room_3();
      }
    }
  }
  else {
    u16 AppliesTo74 = 0;
    for (AppliesTo74 = 0; AppliesTo74 < 256; AppliesTo74++) {
      if (Instances[AppliesTo74].InUse && Instances[AppliesTo74].EName == Object_12) {
        Set_XY(AppliesTo74, 1, 200);
      }
    }
  }
  if (fnaf2 == 0) {
    if (ee == 3) {
      u16 AppliesTo80 = 0;
      for (AppliesTo80 = 0; AppliesTo80 < 256; AppliesTo80++) {
        if (Instances[AppliesTo80].InUse && Instances[AppliesTo80].EName == Object_13) {
          Set_XY(AppliesTo80, 140, 56);
        }
      }
    }
    else {
      u16 AppliesTo84 = 0;
      for (AppliesTo84 = 0; AppliesTo84 < 256; AppliesTo84++) {
        if (Instances[AppliesTo84].InUse && Instances[AppliesTo84].EName == Object_13) {
          Set_XY(AppliesTo84, 1, 200);
        }
      }
    }
  }
  if (fnaf2 == 1) {
    if (ee == 2) {
      u16 AppliesTo91 = 0;
      for (AppliesTo91 = 0; AppliesTo91 < 256; AppliesTo91++) {
        if (Instances[AppliesTo91].InUse && Instances[AppliesTo91].EName == Object_13) {
          Set_XY(AppliesTo91, 160, 40);
        }
      }
    }
    else {
      u16 AppliesTo95 = 0;
      for (AppliesTo95 = 0; AppliesTo95 < 256; AppliesTo95++) {
        if (Instances[AppliesTo95].InUse && Instances[AppliesTo95].EName == Object_13) {
          Set_XY(AppliesTo95, 1, 200);
        }
      }
    }
  }
  if (fnaf2 >= 2) {
    u16 AppliesTo100 = 0;
    for (AppliesTo100 = 0; AppliesTo100 < 256; AppliesTo100++) {
      if (Instances[AppliesTo100].InUse && Instances[AppliesTo100].EName == Object_13) {
        Set_XY(AppliesTo100, 1, 200);
      }
    }
  }
  if (fnaf2 == -1) {
    fnaf2 = 0;
  }
}
void Object_1ButtonPressA_Event(u8 DAppliesTo) {
}


void Set_Sprite(u8 InstanceID, char *SpriteName, bool DeleteOld) {
  Instances[InstanceID].HasSprite = true;
  if (DeleteOld) PA_DeleteSprite(Instances[InstanceID].Screen, InstanceID);
  switch(Sprite_Get_ID(SpriteName)) {
    case 0:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_1_Sprite, OBJ_SIZE_64X64, 1, 0, 256, 192);
      break;
    case 1:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_2_Sprite, OBJ_SIZE_64X64, 1, 0, 256, 192);
      break;
    case 2:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_3_Sprite, OBJ_SIZE_64X64, 1, 0, 256, 192);
      break;
    case 3:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_4_Sprite, OBJ_SIZE_64X64, 1, 0, 256, 192);
      break;
    case 4:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_5_Sprite, OBJ_SIZE_64X64, 1, 0, 256, 192);
      break;
    case 5:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_6_Sprite, OBJ_SIZE_64X64, 1, 1, 256, 192);
      break;
    case 6:
      Instances[InstanceID].Width = 64; Instances[InstanceID].Height = 64;
      PA_CreateSprite(Instances[InstanceID].Screen, InstanceID, (void*)Sprite_7_Sprite, OBJ_SIZE_64X64, 1, 1, 256, 192);
      break;
  }
}

void Create_Object(u8 ObjectEnum, u8 InstanceID, bool Screen, s16 X, s16 Y) {
  Instances[InstanceID].EName = ObjectEnum;  Instances[InstanceID].InUse = true; Instances[InstanceID].Screen = Screen;
  Instances[InstanceID].OriginalX = X; Instances[InstanceID].OriginalY = Y;
  Instances[InstanceID].X = X; Instances[InstanceID].Y = Y;
  Instances[InstanceID].VX = 0; Instances[InstanceID].VY = 0;
  if (ObjectEnum == Object_1) {
     Instances[InstanceID].HasSprite = false;
  } else if (ObjectEnum == Object_2) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_1", false);
  } else if (ObjectEnum == Object_3) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_2", false);
  } else if (ObjectEnum == Object_4) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_3", false);
  } else if (ObjectEnum == Object_5) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_3", false);
  } else if (ObjectEnum == Object_6) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_3", false);
  } else if (ObjectEnum == Object_7) {
     Instances[InstanceID].HasSprite = false;
     Object_7Create_Event(InstanceID);
  } else if (ObjectEnum == Object_8) {
     Instances[InstanceID].HasSprite = false;
     Object_8Create_Event(InstanceID);
  } else if (ObjectEnum == Object_9) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_4", false);
  } else if (ObjectEnum == Object_10) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_4", false);
  } else if (ObjectEnum == Object_11) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_5", false);
  } else if (ObjectEnum == Object_12) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_6", false);
  } else if (ObjectEnum == Object_13) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_6", false);
  } else if (ObjectEnum == Object_14) {
     Instances[InstanceID].HasSprite = true;
     Set_Sprite(InstanceID, "Sprite_7", false);
  }

}
u8 Sprite_Get_ID(char *SpriteName) {
 if (strcmp(SpriteName, "Sprite_1") == 0) return 0;
 if (strcmp(SpriteName, "Sprite_2") == 0) return 1;
 if (strcmp(SpriteName, "Sprite_3") == 0) return 2;
 if (strcmp(SpriteName, "Sprite_4") == 0) return 3;
 if (strcmp(SpriteName, "Sprite_5") == 0) return 4;
 if (strcmp(SpriteName, "Sprite_6") == 0) return 5;
 if (strcmp(SpriteName, "Sprite_7") == 0) return 6;
 return 0;
}

u8 Room_Get_Index(char *RoomName) {
 if (strcmp(RoomName, "Room_4") == 0) return 0;
 if (strcmp(RoomName, "Room_1") == 0) return 1;
 if (strcmp(RoomName, "Room_2") == 0) return 2;
 if (strcmp(RoomName, "Room_3") == 0) return 3;
 return 0;
}

void Goto_Room_Backend(u8 RoomIndex) {
  RoomFrames = 0;
  RoomSeconds = 0;
  if (RoomIndex == 0) Room_4();
  if (RoomIndex == 1) Room_1();
  if (RoomIndex == 2) Room_2();
  if (RoomIndex == 3) Room_3();
}

void Goto_Next_Room(void) {
 if (CurrentRoom < RoomCount) {
  CurrentRoom += 1;
  Goto_Room_Backend(CurrentRoom);
 }
}

