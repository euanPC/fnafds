#include <PA9.h>
#include <dirent.h>
#include <filesystem.h>
#include <unistd.h>
#include "dsgm_gfx.h"
#include "GameWorks.h"


int main (void) {
  RoomCount = 4;
  score = 0;
  lives = 3;
  health = 100;
  CurrentRoom = Room_Get_Index("Room_4");
  swiWaitForVBlank();
  PA_InitFifo();
  PA_Init();
  DSGM_Init_PAlib();
  Reset_Alarms();
  nitroFSInit();
  chdir("nitro:/");
  DSGM_Init_Sound();
  Room_4();
  return 0;
}
bool Room_4(void) {
  PA_ResetSpriteSys();
  PA_ResetBgSys();
  PA_LoadBackground(1, 2, &Background_7);
  PA_LoadSpritePal(1, 0, (void*)DSGMPal0_Pal); PA_LoadSpritePal(0, 0, (void*)DSGMPal0_Pal);
  PA_LoadSpritePal(1, 1, (void*)DSGMPal1_Pal); PA_LoadSpritePal(0, 1, (void*)DSGMPal1_Pal);
  DSGM_Setup_Room(256, 192, 256, 192, 0, 0, 0, 0);
  PA_LoadText(1, 0, &Default); PA_LoadText(0, 0, &Default);
  Create_Object(Object_11, 0, false, 80, 60);
  DSGM_Complete_Room();
  while(true) {
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) Object_1Step_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_4 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_4TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_5 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_5TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_6 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_6TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_11 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_11TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_14 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_14TouchNewPress_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if(Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) {
          if(Pad.Newpress.L) Object_1ButtonPressL_Event(DSGMPL);
          if(Pad.Newpress.R) Object_1ButtonPressR_Event(DSGMPL);
          if(Pad.Newpress.A) Object_1ButtonPressA_Event(DSGMPL);
        }
      }
    }
    Frames += 1;
    RoomFrames += 1;
    if (Frames % 60 == 0) Seconds += 1;
    if (Frames % 60 == 0) RoomSeconds += 1;
    DSGM_ObjectsSync();
    DSGM_AlarmsSync();
    PA_WaitForVBL();
    PA_EasyBgScrollXY(1, 2, RoomData.TopX, RoomData.TopY);
    PA_EasyBgScrollXY(0, 2, RoomData.BottomX, RoomData.BottomY);
  }
  return true;
}
bool Room_1(void) {
  PA_ResetSpriteSys();
  PA_ResetBgSys();
  PA_LoadBackground(1, 2, &Background_1);
  PA_LoadBackground(0, 2, &Background_2);
  PA_LoadSpritePal(1, 0, (void*)DSGMPal0_Pal); PA_LoadSpritePal(0, 0, (void*)DSGMPal0_Pal);
  PA_LoadSpritePal(1, 1, (void*)DSGMPal1_Pal); PA_LoadSpritePal(0, 1, (void*)DSGMPal1_Pal);
  DSGM_Setup_Room(256, 213, 256, 213, 0, 0, 0, 0);
  PA_LoadText(1, 0, &Default); PA_LoadText(0, 0, &Default);
  Create_Object(Object_1, 0, true, 48, 80);
  Create_Object(Object_10, 1, false, 50, 200);
  Create_Object(Object_9, 2, true, 10, 200);
  Create_Object(Object_12, 3, true, 110, 200);
  Create_Object(Object_13, 4, false, 130, 200);
  Create_Object(Object_5, 5, false, 70, 150);
  Create_Object(Object_6, 6, false, 180, 60);
  Create_Object(Object_4, 7, false, 180, 150);
  DSGM_Complete_Room();
  while(true) {
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) Object_1Step_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_4 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_4TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_5 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_5TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_6 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_6TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_11 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_11TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_14 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_14TouchNewPress_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if(Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) {
          if(Pad.Newpress.L) Object_1ButtonPressL_Event(DSGMPL);
          if(Pad.Newpress.R) Object_1ButtonPressR_Event(DSGMPL);
          if(Pad.Newpress.A) Object_1ButtonPressA_Event(DSGMPL);
        }
      }
    }
    Frames += 1;
    RoomFrames += 1;
    if (Frames % 60 == 0) Seconds += 1;
    if (Frames % 60 == 0) RoomSeconds += 1;
    DSGM_ObjectsSync();
    DSGM_AlarmsSync();
    PA_WaitForVBL();
    PA_EasyBgScrollXY(1, 2, RoomData.TopX, RoomData.TopY);
    PA_EasyBgScrollXY(0, 2, RoomData.BottomX, RoomData.BottomY);
  }
  return true;
}
bool Room_2(void) {
  PA_ResetSpriteSys();
  PA_ResetBgSys();
  PA_LoadBackground(1, 2, &Background_5);
  PA_LoadSpritePal(1, 0, (void*)DSGMPal0_Pal); PA_LoadSpritePal(0, 0, (void*)DSGMPal0_Pal);
  PA_LoadSpritePal(1, 1, (void*)DSGMPal1_Pal); PA_LoadSpritePal(0, 1, (void*)DSGMPal1_Pal);
  DSGM_Setup_Room(256, 192, 256, 192, 0, 0, 0, 0);
  PA_LoadText(1, 0, &Default); PA_LoadText(0, 0, &Default);
  Create_Object(Object_7, 0, true, 20, 140);
  Create_Object(Object_14, 1, false, 90, 60);
  DSGM_Complete_Room();
  while(true) {
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) Object_1Step_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_4 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_4TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_5 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_5TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_6 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_6TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_11 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_11TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_14 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_14TouchNewPress_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if(Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) {
          if(Pad.Newpress.L) Object_1ButtonPressL_Event(DSGMPL);
          if(Pad.Newpress.R) Object_1ButtonPressR_Event(DSGMPL);
          if(Pad.Newpress.A) Object_1ButtonPressA_Event(DSGMPL);
        }
      }
    }
    Frames += 1;
    RoomFrames += 1;
    if (Frames % 60 == 0) Seconds += 1;
    if (Frames % 60 == 0) RoomSeconds += 1;
    DSGM_ObjectsSync();
    DSGM_AlarmsSync();
    PA_WaitForVBL();
    PA_EasyBgScrollXY(1, 2, RoomData.TopX, RoomData.TopY);
    PA_EasyBgScrollXY(0, 2, RoomData.BottomX, RoomData.BottomY);
  }
  return true;
}
bool Room_3(void) {
  PA_ResetSpriteSys();
  PA_ResetBgSys();
  PA_LoadBackground(1, 2, &Background_6);
  PA_LoadSpritePal(1, 0, (void*)DSGMPal0_Pal); PA_LoadSpritePal(0, 0, (void*)DSGMPal0_Pal);
  PA_LoadSpritePal(1, 1, (void*)DSGMPal1_Pal); PA_LoadSpritePal(0, 1, (void*)DSGMPal1_Pal);
  DSGM_Setup_Room(256, 192, 256, 192, 0, 0, 0, 0);
  PA_LoadText(1, 0, &Default); PA_LoadText(0, 0, &Default);
  Create_Object(Object_8, 0, true, 50, 80);
  Create_Object(Object_14, 1, false, 90, 70);
  DSGM_Complete_Room();
  while(true) {
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) Object_1Step_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if (Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_4 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_4TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_5 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_5TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_6 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_6TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_11 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_11TouchNewPress_Event(DSGMPL);
        if (Instances[DSGMPL].EName == Object_14 && Stylus.Newpress && PA_SpriteTouched(DSGMPL)) Object_14TouchNewPress_Event(DSGMPL);
      }
    }
    for (DSGMPL = 0; DSGMPL <= 127; DSGMPL++) {
      if(Instances[DSGMPL].InUse) {
        if (Instances[DSGMPL].EName == Object_1) {
          if(Pad.Newpress.L) Object_1ButtonPressL_Event(DSGMPL);
          if(Pad.Newpress.R) Object_1ButtonPressR_Event(DSGMPL);
          if(Pad.Newpress.A) Object_1ButtonPressA_Event(DSGMPL);
        }
      }
    }
    Frames += 1;
    RoomFrames += 1;
    if (Frames % 60 == 0) Seconds += 1;
    if (Frames % 60 == 0) RoomSeconds += 1;
    DSGM_ObjectsSync();
    DSGM_AlarmsSync();
    PA_WaitForVBL();
    PA_EasyBgScrollXY(1, 2, RoomData.TopX, RoomData.TopY);
    PA_EasyBgScrollXY(0, 2, RoomData.BottomX, RoomData.BottomY);
  }
  return true;
}
