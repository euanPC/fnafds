#pragma once
#include <PA_BgStruct.h>
extern const PA_BgStruct Default;
