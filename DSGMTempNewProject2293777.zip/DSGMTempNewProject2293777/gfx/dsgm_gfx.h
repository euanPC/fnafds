#pragma once
#include <PA_BgStruct.h>

//Sprites:
  extern const unsigned char Sprite_1_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_2_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_3_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_4_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_5_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_6_Sprite[4096] _GFX_ALIGN;
  extern const unsigned char Sprite_7_Sprite[4096] _GFX_ALIGN;

//Backgrounds:
  extern const PA_BgStruct Background_1;
  extern const PA_BgStruct Background_2;
  extern const PA_BgStruct Background_3;
  extern const PA_BgStruct Background_4;
  extern const PA_BgStruct Background_5;
  extern const PA_BgStruct Background_6;
  extern const PA_BgStruct Background_7;

//Pallets:
  extern const unsigned short DSGMPal0_Pal[256] _GFX_ALIGN;
  extern const unsigned short DSGMPal1_Pal[256] _GFX_ALIGN;
